# Hangman-Python
A simple hangman game made with python and pygame.

# Requirements
- Python 3.x
- pygame

